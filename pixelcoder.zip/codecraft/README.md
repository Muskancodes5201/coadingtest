# PixelCoder

A browser game for learning to code by controlling a bot through a grid maze.
Twelve levels, four concepts: sequence, loops, conditionals, functions. No
backend, no database - progress is saved in the browser via `localStorage`.

## Stack

- React + Vite
- Phaser 4 for the maze/bot rendering
- Player code runs inside a Web Worker with a hard timeout, so an infinite
  loop in someone's code freezes a background thread, not the tab

## Run it locally

```bash
npm install
npm run dev
```

Then open the URL Vite prints (usually `http://localhost:5173`).

## Build for production

```bash
npm run build
npm run preview   # sanity-check the production build locally
```

## Deploy to GitHub Pages

1. Push this project to a GitHub repo.
2. Run:
   ```bash
   npm run deploy
   ```
   This builds the app and pushes `dist/` to a `gh-pages` branch using the
   `gh-pages` package (already configured in `package.json`).
3. In the repo settings, under **Pages**, set the source to the `gh-pages`
   branch (this is usually configured automatically the first time you run
   `deploy`).
4. Your game will be live at `https://<your-username>.github.io/<repo-name>/`.

`vite.config.js` uses `base: './'` so the build works from any subpath -
no need to hardcode the repo name anywhere.

## How the levels work

Level data lives in `src/data/levels.js` as plain text grids (`S` start,
`G` goal, `#` wall, `C` coin, `.` floor). Each level whitelists which
commands are available (`moveRight`, `pathClear`, etc.), so early levels
can't accidentally use syntax that hasn't been introduced yet.

The star rating compares how many commands the player's solution used
against a hand-checked par for that level (see `src/utils/scoring.js`).

## Project layout

```
src/
  data/levels.js          level definitions
  workers/codeRunner.worker.js   sandboxed execution of player code
  utils/codeRunner.js     spins up the worker, enforces a timeout
  utils/storage.js        localStorage read/write for progress
  utils/scoring.js        star rating + badge list
  game/scenes/MazeScene.js   Phaser scene - drawing + animation
  components/             React UI (editor, sidebar, canvas wrapper, run panel)
```
