import { CONCEPTS, levels } from '../data/levels';

const CONCEPT_LABELS = {
  [CONCEPTS.SEQUENCE]: 'Sequence',
  [CONCEPTS.LOOPS]: 'Loops',
  [CONCEPTS.CONDITIONALS]: 'Conditionals',
  [CONCEPTS.FUNCTIONS]: 'Functions',
};

function StarRow({ count }) {
  return (
    <span className="star-row" aria-label={`${count} of 3 stars`}>
      {[1, 2, 3].map((n) => (
        <span key={n} className={n <= count ? 'star star--filled' : 'star'}>
          ★
        </span>
      ))}
    </span>
  );
}

export default function LevelSidebar({ progress, currentLevelId, onSelect }) {
  const groups = Object.values(CONCEPTS).map((concept) => ({
    concept,
    items: levels.filter((lvl) => lvl.concept === concept),
  }));

  return (
    <nav className="level-sidebar" aria-label="Level select">
      <div className="level-sidebar__brand">
        <span className="level-sidebar__brand-mark" />
        <span className="level-sidebar__brand-name">PixelCoder</span>
      </div>

      {groups.map(({ concept, items }) => (
        <div className="level-group" key={concept}>
          <h3 className="level-group__title">{CONCEPT_LABELS[concept]}</h3>
          <ul className="level-group__list">
            {items.map((lvl) => {
              const unlocked = lvl.id <= progress.unlockedLevel;
              const stars = progress.stars[lvl.id] || 0;
              const isCurrent = lvl.id === currentLevelId;
              return (
                <li key={lvl.id}>
                  <button
                    type="button"
                    className={[
                      'level-item',
                      isCurrent ? 'level-item--active' : '',
                      !unlocked ? 'level-item--locked' : '',
                    ].join(' ').trim()}
                    disabled={!unlocked}
                    onClick={() => onSelect(lvl.id)}
                  >
                    <span className="level-item__index">{lvl.id}</span>
                    <span className="level-item__title">{lvl.title}</span>
                    {unlocked ? <StarRow count={stars} /> : <span className="level-item__lock">🔒</span>}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
    </nav>
  );
}
