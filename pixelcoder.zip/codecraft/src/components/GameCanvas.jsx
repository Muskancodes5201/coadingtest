import { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import Phaser from 'phaser';
import MazeScene from '../game/scenes/MazeScene';

const GameCanvas = forwardRef(function GameCanvas({ level }, ref) {
  const containerRef = useRef(null);
  const gameRef = useRef(null);
  const sceneRef = useRef(null);
  const readyResolverRef = useRef(null);

  useEffect(() => {
    const config = {
      type: Phaser.AUTO,
      parent: containerRef.current,
      width: containerRef.current.clientWidth || 400,
      height: containerRef.current.clientHeight || 320,
      backgroundColor: '#0d1b1e',
      transparent: false,
      scene: [MazeScene],
      physics: { default: undefined },
    };

    const game = new Phaser.Game(config);
    gameRef.current = game;

    game.scene.start('MazeScene', { level });

    game.events.on('maze-ready', () => {
      sceneRef.current = game.scene.getScene('MazeScene');
      if (readyResolverRef.current) {
        readyResolverRef.current();
        readyResolverRef.current = null;
      }
    });

    const resizeObserver = new ResizeObserver(() => {
      if (!containerRef.current) return;
      const { clientWidth, clientHeight } = containerRef.current;
      if (clientWidth === 0 || clientHeight === 0) return;
      game.scale.resize(clientWidth, clientHeight);
      sceneRef.current?.drawBoard();
    });
    resizeObserver.observe(containerRef.current);

    return () => {
      resizeObserver.disconnect();
      game.destroy(true);
      gameRef.current = null;
      sceneRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (sceneRef.current) {
      sceneRef.current.resetBoard(level);
    }
  }, [level]);

  useImperativeHandle(ref, () => ({
    playTrace: (trace, callbacks) => {
      if (!sceneRef.current) return Promise.resolve();
      return sceneRef.current.playTrace(trace, callbacks);
    },
    resetBoard: () => {
      sceneRef.current?.resetBoard(level);
    },
  }));

  return <div ref={containerRef} className="game-canvas" />;
});

export default GameCanvas;
