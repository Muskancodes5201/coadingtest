import { useEffect, useRef } from 'react';

const KEYWORDS = new Set([
  'const', 'let', 'var', 'function', 'return', 'if', 'else', 'for', 'while',
  'break', 'continue', 'true', 'false', 'null', 'undefined', 'new', 'of', 'in',
]);

function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

// A small hand-rolled tokenizer. Not a full JS parser - just enough to
// make the editor feel like a real one for the handful of constructs
// this game actually needs.
function highlight(code, knownCommands) {
  return escapeHtml(code).replace(
    /(\/\/.*$)|("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')|(\b\d+\.?\d*\b)|(\b[a-zA-Z_$][\w$]*\b)/gm,
    (match, comment, string, number, word) => {
      if (comment) return `<span class="tok-comment">${match}</span>`;
      if (string) return `<span class="tok-string">${match}</span>`;
      if (number) return `<span class="tok-number">${match}</span>`;
      if (word) {
        if (KEYWORDS.has(word)) return `<span class="tok-keyword">${match}</span>`;
        if (knownCommands.includes(word)) return `<span class="tok-command">${match}</span>`;
        return match;
      }
      return match;
    }
  );
}

export default function CodeEditor({ value, onChange, availableCommands }) {
  const textareaRef = useRef(null);
  const highlightRef = useRef(null);
  const lineNumbersRef = useRef(null);

  const lineCount = value.split('\n').length;

  const syncScroll = () => {
    if (!textareaRef.current) return;
    const { scrollTop, scrollLeft } = textareaRef.current;
    if (highlightRef.current) {
      highlightRef.current.scrollTop = scrollTop;
      highlightRef.current.scrollLeft = scrollLeft;
    }
    if (lineNumbersRef.current) {
      lineNumbersRef.current.scrollTop = scrollTop;
    }
  };

  useEffect(syncScroll, [value]);

  const handleKeyDown = (e) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const el = textareaRef.current;
      const start = el.selectionStart;
      const end = el.selectionEnd;
      const next = `${value.slice(0, start)}  ${value.slice(end)}`;
      onChange(next);
      requestAnimationFrame(() => {
        el.selectionStart = el.selectionEnd = start + 2;
      });
    }
  };

  return (
    <div className="code-editor">
      <div className="code-editor__gutter" ref={lineNumbersRef}>
        {Array.from({ length: lineCount }, (_, i) => (
          <div key={i} className="code-editor__line-number">{i + 1}</div>
        ))}
      </div>
      <div className="code-editor__body">
        <pre className="code-editor__highlight" ref={highlightRef} aria-hidden="true">
          <code dangerouslySetInnerHTML={{ __html: `${highlight(value, availableCommands)}\n` }} />
        </pre>
        <textarea
          ref={textareaRef}
          className="code-editor__input"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onScroll={syncScroll}
          onKeyDown={handleKeyDown}
          spellCheck={false}
          autoCapitalize="off"
          autoCorrect="off"
          placeholder="// write your code here"
        />
      </div>
    </div>
  );
}
