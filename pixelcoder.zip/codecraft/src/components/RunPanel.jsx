export default function RunPanel({
  level,
  onRun,
  onResetCode,
  isRunning,
  status,
  hintIndex,
  onShowHint,
  lastStars,
}) {
  return (
    <div className="run-panel">
      <div className="run-panel__intro">
        <h2>{level.title}</h2>
        <p>{level.intro}</p>
      </div>

      <div className="run-panel__commands">
        <span className="run-panel__commands-label">Available:</span>
        {level.availableCommands.map((cmd) => (
          <code key={cmd} className="command-chip">{cmd}()</code>
        ))}
      </div>

      <div className="run-panel__actions">
        <button type="button" className="btn btn--primary" onClick={onRun} disabled={isRunning}>
          {isRunning ? 'Running…' : '▶ Run Code'}
        </button>
        <button type="button" className="btn btn--ghost" onClick={onResetCode} disabled={isRunning}>
          Reset Code
        </button>
        <button type="button" className="btn btn--ghost" onClick={onShowHint} disabled={isRunning}>
          💡 Hint {hintIndex > 0 ? `(${hintIndex}/${level.hints.length})` : ''}
        </button>
      </div>

      {hintIndex > 0 && (
        <div className="hint-box">
          {level.hints.slice(0, hintIndex).map((hint, i) => (
            <p key={i}>{hint}</p>
          ))}
        </div>
      )}

      {status && (
        <div className={`status-box status-box--${status.type}`}>
          <p>{status.text}</p>
          {status.type === 'success' && lastStars && (
            <span className="star-row status-box__stars">
              {[1, 2, 3].map((n) => (
                <span key={n} className={n <= lastStars ? 'star star--filled' : 'star'}>★</span>
              ))}
            </span>
          )}
        </div>
      )}
    </div>
  );
}
