import Phaser from 'phaser';

const COLORS = {
  floor: 0x18313a,
  floorAlt: 0x14292f,
  wall: 0x0a1a1f,
  grid: 0x2c4a52,
  bot: 0x4fd1c5,
  botCore: 0xeaf6f4,
  goal: 0xc98a4b,
  coin: 0xf2c14e,
};

export default class MazeScene extends Phaser.Scene {
  constructor() {
    super('MazeScene');
    this.level = null;
    this.tileSize = 56;
    this.coinSprites = {};
  }

  init(data) {
    this.level = data.level;
  }

  create() {
    this.drawBoard();
    this.game.events.emit('maze-ready');
  }

  resetBoard(level) {
    this.level = level;
    this.drawBoard();
    this.game.events.emit('maze-ready');
  }

  drawBoard() {
    this.children.removeAll();
    const grid = this.level.grid;
    const rows = grid.length;
    const cols = grid[0].length;

    const maxWidth = this.scale.width - 32;
    const maxHeight = this.scale.height - 32;
    this.tileSize = Math.floor(Math.min(maxWidth / cols, maxHeight / rows, 92));
    this.offsetX = (this.scale.width - cols * this.tileSize) / 2;
    this.offsetY = (this.scale.height - rows * this.tileSize) / 2;

    const board = this.add.graphics();
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const isWall = grid[r][c] === '#';
        const x = this.offsetX + c * this.tileSize;
        const y = this.offsetY + r * this.tileSize;
        const fill = isWall ? COLORS.wall : (r + c) % 2 === 0 ? COLORS.floor : COLORS.floorAlt;
        board.fillStyle(fill, 1);
        board.fillRoundedRect(x + 2, y + 2, this.tileSize - 4, this.tileSize - 4, 6);
        if (!isWall) {
          board.lineStyle(1, COLORS.grid, 0.5);
          board.strokeRoundedRect(x + 2, y + 2, this.tileSize - 4, this.tileSize - 4, 6);
        }
      }
    }

    const goalPos = this.findCell('G');
    if (goalPos) {
      const { x, y } = this.cellCenter(...goalPos);
      const ring = this.add.circle(x, y, this.tileSize * 0.32, 0x000000, 0);
      ring.setStrokeStyle(3, COLORS.goal, 1);
      this.tweens.add({
        targets: ring,
        scale: { from: 0.85, to: 1.12 },
        alpha: { from: 1, to: 0.45 },
        duration: 900,
        yoyo: true,
        repeat: -1,
      });
    }

    this.coinSprites = {};
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (grid[r][c] === 'C') {
          const { x, y } = this.cellCenter(r, c);
          const coin = this.add.circle(x, y, this.tileSize * 0.16, COLORS.coin, 1);
          coin.setStrokeStyle(2, 0xffffff, 0.45);
          this.coinSprites[`${r},${c}`] = coin;
        }
      }
    }

    const startPos = this.findCell('S') || [0, 0];
    const { x: bx, y: by } = this.cellCenter(...startPos);
    this.bot = this.add.container(bx, by);
    const body = this.add.circle(0, 0, this.tileSize * 0.3, COLORS.bot, 1);
    const core = this.add.circle(0, 0, this.tileSize * 0.12, COLORS.botCore, 1);
    this.bot.add([body, core]);
  }

  findCell(letter) {
    const grid = this.level.grid;
    for (let r = 0; r < grid.length; r++) {
      for (let c = 0; c < grid[r].length; c++) {
        if (grid[r][c] === letter) return [r, c];
      }
    }
    return null;
  }

  cellCenter(r, c) {
    return {
      x: this.offsetX + c * this.tileSize + this.tileSize / 2,
      y: this.offsetY + r * this.tileSize + this.tileSize / 2,
    };
  }

  bumpOffset(dir) {
    const map = { right: [1, 0], left: [-1, 0], up: [0, -1], down: [0, 1] };
    const [dx, dy] = map[dir] || [0, 0];
    return { x: dx * 9, y: dy * 9 };
  }

  async playTrace(trace, callbacks = {}) {
    for (const step of trace) {
      // Steps must play in order, one after another - that's the point.
      // eslint-disable-next-line no-await-in-loop
      await this.playStep(step, callbacks);
    }
  }

  playStep(step, { onCoin, onBump } = {}) {
    return new Promise((resolve) => {
      if (step.type === 'move') {
        const { x, y } = this.cellCenter(...step.at);
        this.tweens.add({ targets: this.bot, x, y, duration: 200, ease: 'Quad.easeInOut', onComplete: resolve });
      } else if (step.type === 'bump') {
        if (onBump) onBump();
        const offset = this.bumpOffset(step.dir);
        this.tweens.add({
          targets: this.bot,
          x: this.bot.x + offset.x,
          y: this.bot.y + offset.y,
          duration: 80,
          yoyo: true,
          ease: 'Quad.easeOut',
          onComplete: resolve,
        });
      } else if (step.type === 'collect') {
        const coin = this.coinSprites[`${step.at[0]},${step.at[1]}`];
        if (coin) {
          if (onCoin) onCoin();
          this.tweens.add({
            targets: coin,
            scale: 0,
            alpha: 0,
            duration: 180,
            onComplete: () => {
              coin.destroy();
              resolve();
            },
          });
        } else {
          resolve();
        }
      } else {
        resolve();
      }
    });
  }
}
