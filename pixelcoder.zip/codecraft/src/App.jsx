import { useEffect, useMemo, useRef, useState } from 'react';
import LevelSidebar from './components/LevelSidebar';
import CodeEditor from './components/CodeEditor';
import GameCanvas from './components/GameCanvas';
import RunPanel from './components/RunPanel';
import { getLevelById, totalLevels, CONCEPTS, levels } from './data/levels';
import { loadProgress, saveProgress, resetProgress } from './utils/storage';
import { runPlayerCode } from './utils/codeRunner';
import { starsForRun, BADGES } from './utils/scoring';

function conceptComplete(progress, concept) {
  const conceptLevels = levels.filter((lvl) => lvl.concept === concept);
  return conceptLevels.every((lvl) => (progress.stars[lvl.id] || 0) > 0);
}

export default function App() {
  const [progress, setProgress] = useState(loadProgress);
  const [currentLevelId, setCurrentLevelId] = useState(() => {
    const initial = loadProgress();
    return Math.min(initial.unlockedLevel, totalLevels);
  });
  const [isRunning, setIsRunning] = useState(false);
  const [status, setStatus] = useState(null);
  const [lastStars, setLastStars] = useState(null);
  const [hintCounts, setHintCounts] = useState({});
  const [badgeToast, setBadgeToast] = useState(null);

  const gameCanvasRef = useRef(null);
  const toastTimerRef = useRef(null);

  const level = useMemo(() => getLevelById(currentLevelId), [currentLevelId]);
  const code = progress.codeByLevel[currentLevelId] ?? level.starterCode;
  const hintIndex = hintCounts[currentLevelId] || 0;

  useEffect(() => {
    saveProgress(progress);
  }, [progress]);

  useEffect(() => () => clearTimeout(toastTimerRef.current), []);

  const handleSelectLevel = (id) => {
    if (id > progress.unlockedLevel) return;
    setCurrentLevelId(id);
    setStatus(null);
    setLastStars(null);
  };

  const handleCodeChange = (newCode) => {
    setProgress((prev) => ({
      ...prev,
      codeByLevel: { ...prev.codeByLevel, [currentLevelId]: newCode },
    }));
  };

  const handleResetCode = () => {
    handleCodeChange(level.starterCode);
    setStatus(null);
  };

  const handleShowHint = () => {
    setHintCounts((prev) => {
      const current = prev[currentLevelId] || 0;
      const next = Math.min(current + 1, level.hints.length);
      return { ...prev, [currentLevelId]: next };
    });
  };

  const announceBadge = (badge) => {
    setBadgeToast(badge);
    clearTimeout(toastTimerRef.current);
    toastTimerRef.current = setTimeout(() => setBadgeToast(null), 3500);
  };

  const handleRun = async () => {
    setIsRunning(true);
    setStatus(null);
    setLastStars(null);
    gameCanvasRef.current?.resetBoard();

    const outcome = await runPlayerCode(code, level);

    if (!outcome.ok) {
      setStatus({ type: 'error', text: outcome.error });
      setIsRunning(false);
      return;
    }

    const { result } = outcome;
    await gameCanvasRef.current?.playTrace(result.trace, {});

    if (result.success) {
      const stars = starsForRun(result.commandsUsed, level.parCommands);
      setLastStars(stars);

      let coinNote = '';
      if (result.totalCoins > 0) {
        coinNote = ` You collected ${result.coinsCollected}/${result.totalCoins} coins.`;
      }
      setStatus({
        type: 'success',
        text: `Level complete in ${result.commandsUsed} commands (par is ${level.parCommands}).${coinNote}`,
      });

      setProgress((prev) => {
        const nextUnlocked = Math.max(prev.unlockedLevel, Math.min(level.id + 1, totalLevels));
        const prevStars = prev.stars[level.id] || 0;
        const nextStars = { ...prev.stars, [level.id]: Math.max(prevStars, stars) };

        const newlyCompleteBadges = [...prev.badges];
        Object.values(CONCEPTS).forEach((concept) => {
          const badgeMeta = BADGES.find((b) => b.id === concept);
          const alreadyEarned = prev.badges.includes(concept);
          const complete = conceptComplete({ ...prev, stars: nextStars }, concept);
          if (complete && !alreadyEarned) {
            newlyCompleteBadges.push(concept);
            announceBadge(badgeMeta);
          }
        });

        return {
          ...prev,
          unlockedLevel: nextUnlocked,
          stars: nextStars,
          badges: newlyCompleteBadges,
        };
      });
    } else {
      const reason = result.commandsUsed === 0
        ? "Your code didn't move the bot at all - try calling one of the commands on the left."
        : "The bot didn't reach the goal. Trace through the grid again and check your directions.";
      setStatus({ type: 'error', text: reason });
    }

    setIsRunning(false);
  };

  const handleResetProgress = () => {
    if (!window.confirm('This clears every star, unlocked level, and saved code. Continue?')) return;
    const fresh = resetProgress();
    setProgress(fresh);
    setCurrentLevelId(1);
    setStatus(null);
    setLastStars(null);
    setHintCounts({});
  };

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="app-header__title">
          <span className="app-header__mark" />
          <h1>PixelCoder</h1>
          <span className="app-header__tag">learn to code by moving a bot</span>
        </div>
        <div className="app-header__meta">
          <span className="badge-count">{progress.badges.length}/{BADGES.length} badges</span>
          <button type="button" className="btn btn--ghost btn--small" onClick={handleResetProgress}>
            Reset progress
          </button>
        </div>
      </header>

      <div className="app-body">
        <LevelSidebar progress={progress} currentLevelId={currentLevelId} onSelect={handleSelectLevel} />

        <main className="editor-pane">
          <CodeEditor value={code} onChange={handleCodeChange} availableCommands={level.availableCommands} />
        </main>

        <aside className="game-pane">
          <GameCanvas ref={gameCanvasRef} level={level} />
          <RunPanel
            level={level}
            onRun={handleRun}
            onResetCode={handleResetCode}
            isRunning={isRunning}
            status={status}
            hintIndex={hintIndex}
            onShowHint={handleShowHint}
            lastStars={lastStars}
          />
        </aside>
      </div>

      {badgeToast && (
        <div className="badge-toast">
          <strong>Badge earned: {badgeToast.label}</strong>
          <span>{badgeToast.description}</span>
        </div>
      )}
    </div>
  );
}
