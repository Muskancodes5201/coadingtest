// Each level is drawn as a simple text grid.
// . = open floor   # = wall   S = start   G = goal   C = coin (optional, bonus)
//
// Grid rows are read top to bottom, columns left to right.
// Keeping levels as plain strings makes them easy to sketch out and tweak by hand.

const G = (rows) => rows.map((row) => row.split(''));

export const CONCEPTS = {
  SEQUENCE: 'sequence',
  LOOPS: 'loops',
  CONDITIONALS: 'conditionals',
  FUNCTIONS: 'functions',
};

export const levels = [
  // ---------------- SEQUENCE ----------------
  {
    id: 1,
    concept: CONCEPTS.SEQUENCE,
    title: 'First Steps',
    intro: 'Move the bot from S to G using moveRight() and moveDown(). Every line runs top to bottom, in order.',
    grid: G([
      'S..',
      '...',
      '..G',
    ]),
    availableCommands: ['moveRight', 'moveDown', 'moveLeft', 'moveUp'],
    parCommands: 4,
    hints: [
      'You need to move right twice and down twice.',
      'Try: moveRight(); moveRight(); moveDown(); moveDown();',
    ],
    starterCode: '// write your code below\nmoveRight();\n',
  },
  {
    id: 2,
    concept: CONCEPTS.SEQUENCE,
    title: 'Around the Wall',
    intro: 'A wall blocks the straight line. Walk around it, one command per step.',
    grid: G([
      'S..',
      '.#.',
      '..G',
    ]),
    availableCommands: ['moveRight', 'moveDown', 'moveLeft', 'moveUp'],
    parCommands: 4,
    hints: [
      'Going straight down runs into the wall.',
      'Go right first, then down twice, then... check the grid again.',
    ],
    starterCode: '// the wall is in the middle - go around it\n',
  },
  {
    id: 3,
    concept: CONCEPTS.SEQUENCE,
    title: 'Coin Detour',
    intro: 'Collect the coin on your way to the goal with collectCoin(). You must be standing on it first.',
    grid: G([
      'S...',
      '.#C.',
      '....',
      '...G',
    ]),
    availableCommands: ['moveRight', 'moveDown', 'moveLeft', 'moveUp', 'collectCoin'],
    parCommands: 7,
    hints: [
      'Move onto the C tile before calling collectCoin().',
      'Order: right, right, down, collectCoin(), down, down, right.',
    ],
    starterCode: '// grab the coin, then reach G\n',
  },

  // ---------------- LOOPS ----------------
  {
    id: 4,
    concept: CONCEPTS.LOOPS,
    title: 'A Long Hallway',
    intro: 'Writing moveRight() five times works, but a for loop says the same thing in three lines.',
    grid: G([
      'S.....G',
    ]),
    availableCommands: ['moveRight', 'moveLeft', 'moveUp', 'moveDown'],
    parCommands: 6,
    hints: [
      'for (let i = 0; i < 6; i++) { moveRight(); }',
      'The loop body runs once per lap - six laps, six moves.',
    ],
    starterCode: 'for (let i = 0; i < 1; i++) {\n  moveRight();\n}\n',
  },
  {
    id: 5,
    concept: CONCEPTS.LOOPS,
    title: 'Two Straights',
    intro: 'Two separate loops: one to go right, one to go down.',
    grid: G([
      'S....',
      '....#',
      '....#',
      '....#',
      '....G',
    ]),
    availableCommands: ['moveRight', 'moveDown', 'moveLeft', 'moveUp'],
    parCommands: 8,
    hints: [
      'The right-hand column is blocked - go down the left side first.',
      'First loop moves down 4 times, second loop moves right 4 times.',
    ],
    starterCode: '',
  },
  {
    id: 6,
    concept: CONCEPTS.LOOPS,
    title: 'Staircase',
    intro: 'Nest the pattern: right, down, right, down. A loop can hold more than one command.',
    grid: G([
      'S.###',
      '#..##',
      '##..#',
      '###..',
      '####G',
    ]),
    availableCommands: ['moveRight', 'moveDown', 'moveLeft', 'moveUp'],
    parCommands: 8,
    hints: [
      'The only open floor zig-zags - right, down, right, down, all the way.',
      'for (let i = 0; i < 4; i++) { moveRight(); moveDown(); }',
    ],
    starterCode: '',
  },

  // ---------------- CONDITIONALS ----------------
  {
    id: 7,
    concept: CONCEPTS.CONDITIONALS,
    title: 'Is the Path Clear?',
    intro: 'Use pathClear("right") to check before you step. It returns true or false without moving.',
    grid: G([
      'S.#..',
      '....G',
    ]),
    availableCommands: ['moveRight', 'moveDown', 'moveLeft', 'moveUp', 'pathClear'],
    parCommands: 5,
    hints: [
      'Take one step right, then check pathClear("right") before your next move.',
      'moveRight(); if (pathClear("right")) { moveRight(); } else { moveDown(); } then finish with moveRight() three times.',
    ],
    starterCode: 'moveRight();\nif (pathClear("right")) {\n  moveRight();\n} else {\n  moveDown();\n}\n// now get yourself the rest of the way to G\n',
  },
  {
    id: 8,
    concept: CONCEPTS.CONDITIONALS,
    title: 'Choose a Direction',
    intro: 'Combine a loop with a condition so the bot decides its own route around each wall it meets.',
    grid: G([
      'S.#..',
      '..#..',
      '....G',
    ]),
    availableCommands: ['moveRight', 'moveDown', 'moveLeft', 'moveUp', 'pathClear', 'atGoal'],
    parCommands: 7,
    hints: [
      'while (!atGoal()) { if (pathClear("right")) { moveRight(); } else { moveDown(); } }',
      'atGoal() tells you when to stop the loop.',
    ],
    starterCode: 'while (!atGoal()) {\n  if (pathClear("right")) {\n    moveRight();\n  } else {\n    moveDown();\n  }\n}\n',
  },
  {
    id: 9,
    concept: CONCEPTS.CONDITIONALS,
    title: 'Coin or No Coin',
    intro: 'Only collect the coin if one is actually there. hasCoinHere() checks the current tile.',
    grid: G([
      'S.C..',
      '.....',
      '..C.G',
    ]),
    availableCommands: ['moveRight', 'moveDown', 'moveLeft', 'moveUp', 'collectCoin', 'hasCoinHere'],
    parCommands: 8,
    hints: [
      'After every move, check: if (hasCoinHere()) { collectCoin(); }',
      'Walk the whole path and test each tile as you land on it.',
    ],
    starterCode: '',
  },

  // ---------------- FUNCTIONS ----------------
  {
    id: 10,
    concept: CONCEPTS.FUNCTIONS,
    title: 'Name Your Moves',
    intro: 'Wrap a repeated pattern in your own function so you can call it by name.',
    grid: G([
      'S....',
      '.....',
      '....G',
    ]),
    availableCommands: ['moveRight', 'moveDown', 'moveLeft', 'moveUp'],
    parCommands: 6,
    hints: [
      'function goRightTwice() { moveRight(); moveRight(); }',
      'Define the function once, then call it as many times as you need.',
    ],
    starterCode: 'function goRightTwice() {\n  moveRight();\n  moveRight();\n}\n\ngoRightTwice();\n',
  },
  {
    id: 11,
    concept: CONCEPTS.FUNCTIONS,
    title: 'The L Shape',
    intro: 'Write one function that performs the whole L-shaped turn, then reuse it.',
    grid: G([
      'S..#..',
      '...#..',
      '...#..',
      '......',
      '#....G',
    ]),
    availableCommands: ['moveRight', 'moveDown', 'moveLeft', 'moveUp'],
    parCommands: 9,
    hints: [
      'function lTurn() { moveDown(); moveDown(); moveDown(); moveRight(); }',
      'Call lTurn() once, then moveRight() four more times and moveDown() once to finish.',
    ],
    starterCode: '',
  },
  {
    id: 12,
    concept: CONCEPTS.FUNCTIONS,
    title: 'Full Route',
    intro: 'Put it all together: functions, loops and a condition to reach the goal and grab every coin.',
    grid: G([
      'S..#....',
      '.C.#.C..',
      '...#....',
      '........',
      '#..#...G',
    ]),
    availableCommands: [
      'moveRight', 'moveDown', 'moveLeft', 'moveUp',
      'pathClear', 'atGoal', 'hasCoinHere', 'collectCoin',
    ],
    parCommands: 13,
    hints: [
      'Build a small step() function that moves and then checks hasCoinHere().',
      'Loop step() with pathClear() checks until atGoal() is true.',
    ],
    starterCode: '',
  },
];

export const getLevelById = (id) => levels.find((lvl) => lvl.id === id);

export const totalLevels = levels.length;
