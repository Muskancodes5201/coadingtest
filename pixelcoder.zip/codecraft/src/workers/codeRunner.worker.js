// This worker takes the player's JS, runs it against a tiny simulated
// version of the level (no rendering here), and hands back a list of
// steps the main thread can play back with Phaser. Keeping execution in
// a worker means a runaway loop freezes a background thread, not the tab.

const MAX_STEPS = 800;

const DIRECTIONS = {
  right: [0, 1],
  left: [0, -1],
  up: [-1, 0],
  down: [1, 0],
};

function buildBoard(grid) {
  const rows = grid.length;
  const cols = grid[0].length;
  let start = null;
  let goal = null;
  const coins = new Set();

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const cell = grid[r][c];
      if (cell === 'S') start = [r, c];
      if (cell === 'G') goal = [r, c];
      if (cell === 'C') coins.add(`${r},${c}`);
    }
  }

  return { rows, cols, start, goal, coins };
}

function isWall(grid, rows, cols, r, c) {
  if (r < 0 || c < 0 || r >= rows || c >= cols) return true;
  return grid[r][c] === '#';
}

function runLevel(code, grid, availableCommands) {
  const { rows, cols, start, goal, coins } = buildBoard(grid);
  const remainingCoins = new Set(coins);
  const totalCoins = coins.size;

  let pos = [...start];
  let stepCount = 0;
  let commandsUsed = 0;
  const trace = [];

  const guard = () => {
    stepCount += 1;
    if (stepCount > MAX_STEPS) {
      throw new RunnerError(
        `Your code ran for more than ${MAX_STEPS} steps. Check for a loop that never ends.`
      );
    }
  };

  const move = (dir) => {
    guard();
    commandsUsed += 1;
    const [dr, dc] = DIRECTIONS[dir];
    const target = [pos[0] + dr, pos[1] + dc];
    const blocked = isWall(grid, rows, cols, target[0], target[1]);

    if (blocked) {
      trace.push({ type: 'bump', dir, at: [...pos] });
    } else {
      pos = target;
      trace.push({ type: 'move', dir, at: [...pos] });
    }
    return !blocked;
  };

  const pathClear = (dir) => {
    guard();
    if (!DIRECTIONS[dir]) {
      throw new RunnerError(`pathClear() needs "up", "down", "left" or "right" - got "${dir}".`);
    }
    const [dr, dc] = DIRECTIONS[dir];
    return !isWall(grid, rows, cols, pos[0] + dr, pos[1] + dc);
  };

  const atGoal = () => {
    guard();
    return pos[0] === goal[0] && pos[1] === goal[1];
  };

  const hasCoinHere = () => {
    guard();
    return remainingCoins.has(`${pos[0]},${pos[1]}`);
  };

  const collectCoin = () => {
    guard();
    const key = `${pos[0]},${pos[1]}`;
    if (remainingCoins.has(key)) {
      remainingCoins.delete(key);
      commandsUsed += 1;
      trace.push({ type: 'collect', at: [...pos] });
      return true;
    }
    trace.push({ type: 'collect-empty', at: [...pos] });
    return false;
  };

  const api = {
    moveRight: () => move('right'),
    moveLeft: () => move('left'),
    moveUp: () => move('up'),
    moveDown: () => move('down'),
    pathClear,
    atGoal,
    hasCoinHere,
    collectCoin,
  };

  const paramNames = availableCommands.filter((name) => name in api);
  const paramFns = paramNames.map((name) => api[name]);

  // eslint-disable-next-line no-new-func
  const sandboxed = new Function(...paramNames, `"use strict";\n${code}\n`);
  sandboxed(...paramFns);

  return {
    success: pos[0] === goal[0] && pos[1] === goal[1],
    finalPosition: pos,
    commandsUsed,
    coinsCollected: totalCoins - remainingCoins.size,
    totalCoins,
    trace,
  };
}

class RunnerError extends Error {}

self.onmessage = (event) => {
  const { code, grid, availableCommands } = event.data;
  try {
    const result = runLevel(code, grid, availableCommands);
    self.postMessage({ ok: true, result });
  } catch (err) {
    const friendly = translateError(err);
    self.postMessage({ ok: false, error: friendly });
  }
};

function translateError(err) {
  if (err instanceof RunnerError) return err.message;

  const msg = err && err.message ? err.message : 'Something went wrong running your code.';

  // "moveRight is not defined" reads oddly to a beginner - reword it.
  const notDefined = msg.match(/^(\w+) is not defined$/);
  if (notDefined) {
    return `"${notDefined[1]}" isn't available on this level yet - check the command list on the left.`;
  }
  if (msg.includes('Unexpected token') || msg.includes('SyntaxError') || err instanceof SyntaxError) {
    return `There's a syntax error in your code: ${msg}`;
  }
  return msg;
}
