const WORKER_TIMEOUT_MS = 2000;

/**
 * Runs player code against a level inside a Web Worker so an infinite
 * loop in their code can't lock up the page. Resolves with either
 * { ok: true, result } or { ok: false, error }.
 */
export function runPlayerCode(code, level) {
  return new Promise((resolve) => {
    const worker = new Worker(new URL('../workers/codeRunner.worker.js', import.meta.url), {
      type: 'module',
    });

    let settled = false;
    const finish = (payload) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      worker.terminate();
      resolve(payload);
    };

    const timer = setTimeout(() => {
      finish({
        ok: false,
        error: "Your code took too long to finish - look for a loop that never stops (like while(true)).",
      });
    }, WORKER_TIMEOUT_MS);

    worker.onmessage = (event) => finish(event.data);
    worker.onerror = (event) => {
      finish({ ok: false, error: event.message || 'Your code crashed while running.' });
    };

    worker.postMessage({
      code,
      grid: level.grid,
      availableCommands: level.availableCommands,
    });
  });
}
