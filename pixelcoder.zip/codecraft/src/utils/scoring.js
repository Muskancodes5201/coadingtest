// Stars reward writing tight code, not just reaching the goal.
// 3 stars: at or under par. 2 stars: within 50% over par. 1 star: solved at all.
export function starsForRun(commandsUsed, parCommands) {
  if (commandsUsed <= parCommands) return 3;
  if (commandsUsed <= parCommands * 1.5) return 2;
  return 1;
}

export const BADGES = [
  { id: 'sequence', label: 'First Sequence', description: 'Finished every Sequence level.' },
  { id: 'loops', label: 'Loop Master', description: 'Finished every Loops level.' },
  { id: 'conditionals', label: 'Decision Maker', description: 'Finished every Conditionals level.' },
  { id: 'functions', label: 'Function Architect', description: 'Finished every Functions level.' },
];
