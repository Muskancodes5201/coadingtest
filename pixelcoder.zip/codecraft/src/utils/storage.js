const STORAGE_KEY = 'codecraft.progress.v1';

const defaultProgress = () => ({
  unlockedLevel: 1,
  stars: {}, // { [levelId]: 1 | 2 | 3 }
  codeByLevel: {}, // { [levelId]: string } - remembers what the player last typed
  badges: [],
});

export function loadProgress() {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultProgress();
    const parsed = JSON.parse(raw);
    return { ...defaultProgress(), ...parsed };
  } catch (err) {
    console.warn('Could not read saved progress, starting fresh.', err);
    return defaultProgress();
  }
}

export function saveProgress(progress) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch (err) {
    console.warn('Could not save progress.', err);
  }
}

export function resetProgress() {
  try {
    window.localStorage.removeItem(STORAGE_KEY);
  } catch (err) {
    console.warn('Could not clear saved progress.', err);
  }
  return defaultProgress();
}
