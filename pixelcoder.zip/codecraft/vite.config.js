import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// base: './' keeps built asset paths relative, so this works whether it's
// served from a domain root or a GitHub Pages project subpath.
export default defineConfig({
  base: './',
  plugins: [react()],
})
